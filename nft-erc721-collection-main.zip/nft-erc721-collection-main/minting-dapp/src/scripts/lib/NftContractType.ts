// The name below ("YourNftToken") should match the name of your Solidity contract.
// It can be updated using the following command:
// yarn rename-contract NEW_CONTRACT_NAME
// Please DO NOT change it manually!
import { YourNftToken as NftContractType } from '../../../../smart-contract/typechain/index';

export default NftContractType;
